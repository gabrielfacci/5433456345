<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('vip_rewards', function (Blueprint $table) {
            $table->id();
            $table->string('title')->comment('Título da recompensa');
            $table->text('description')->nullable()->comment('Descrição da recompensa');
            $table->enum('type', ['money', 'spins', 'cashback', 'bonus'])->default('money')->comment('Tipo de recompensa');
            $table->decimal('value', 20, 2)->default(0)->comment('Valor da recompensa');
            $table->integer('spins_quantity')->nullable()->comment('Quantidade de giros grátis');
            $table->string('game_id')->nullable()->comment('ID do jogo para giros grátis');
            $table->integer('vip_level_required')->default(1)->comment('Nível VIP necessário');
            $table->decimal('points_cost', 20, 2)->default(0)->comment('Custo em pontos VIP');
            $table->string('icon')->nullable()->comment('Ícone da recompensa');
            $table->string('image')->nullable()->comment('Imagem da recompensa');
            $table->enum('status', ['active', 'inactive'])->default('active')->comment('Status da recompensa');
            $table->integer('daily_limit')->nullable()->comment('Limite diário de resgates');
            $table->integer('total_limit')->nullable()->comment('Limite total de resgates');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('vip_rewards');
    }
}; 