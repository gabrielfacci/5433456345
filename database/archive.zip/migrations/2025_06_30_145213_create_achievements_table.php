<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('achievements', function (Blueprint $table) {
            $table->id();
            $table->string('title');
            $table->text('description')->nullable();
            $table->string('icon')->nullable(); // emoji ou url
            $table->string('image')->nullable();
            $table->integer('vip_points_reward')->default(0); // pontos dados ao desbloquear
            $table->string('requirement_type'); // ex: apostas, missões, depósitos, etc
            $table->integer('requirement_value'); // valor necessário para desbloquear
            $table->boolean('active')->default(true);
            $table->string('status')->default('active');
            $table->integer('total_limit')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('achievements');
    }
};
