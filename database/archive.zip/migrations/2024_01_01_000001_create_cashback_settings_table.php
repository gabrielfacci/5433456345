<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('cashback_settings', function (Blueprint $table) {
            $table->id();
            // Percentual de cashback (ex.: 10.00 para 10%)
            $table->decimal('percentual', 5, 2)->default(10.00);
            // periodicidade pode ser: daily, weekly ou monthly
            $table->enum('periodicidade', ['daily', 'weekly', 'monthly'])->default('weekly');
            $table->timestamps();
        });

        // cria um registro padrão
        \DB::table('cashback_settings')->insert([
            'percentual'    => 10.00,
            'periodicidade' => 'weekly',
            'created_at'    => now(),
            'updated_at'    => now(),
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('cashback_settings');
    }
}; 